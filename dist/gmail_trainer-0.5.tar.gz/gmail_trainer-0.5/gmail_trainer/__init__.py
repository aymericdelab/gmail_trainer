from gmail_trainer.send_mail import SendMail
